package Painter;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.*;
import javafx.scene.image.WritableImage;
import javafx.scene.input.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class Controller {

    @FXML
    Pane canvasPane;
    @FXML
    TextField resolutionWidth;
    @FXML
    TextField resolutionHeight;
    @FXML
    ComboBox toolComboBox;
    @FXML
    Slider toolSizeSlider;
    @FXML
    ColorPicker toolColorPicker;

    //Default Unchangeable values
    final int undoListMaxSize = 25, toolSizeMin = 1, toolSizeMax = 20, scrollSizeStep = 2, minResolution = 128, maxResolution = 2048;

    //Default initial values
    int width = 256, height = 256;
    float previousDrawPositionX = -1, previousDrawPositionY = -1;
    Circle CanvasCursor = null;
    Color penColor = Color.BLUE;
    boolean isPenSelected = true;
    ArrayList<UndoElement> undoList = new ArrayList();
    final int toolSizeInitial = 5;
    Path path = null;


    //This will run only once, for the first frame (first refresh cycle)
    public void initialize() {
        toolComboBox.getItems().setAll("Pen", "Eraser");
        toolComboBox.setValue("Pen");
        resolutionWidth.setText(width+"");
        resolutionHeight.setText(height+"");
        initializeCanvas();
        toolColorPicker.setValue(penColor);
        toolSizeSlider.setMin(toolSizeMin);
        toolSizeSlider.setMax(toolSizeMax);
        toolSizeSlider.setValue(toolSizeInitial);
    }

    //Resize canvas to last known width/height, Mask outside the canvas, reset undoList
    private void initializeCanvas() {
        canvasPane.setPrefWidth(width);
        canvasPane.setPrefHeight(height);
        canvasPane.getChildren().clear();
        Rectangle canvasMask = new Rectangle();
        canvasMask.setX(canvasPane.getLayoutX());
        canvasMask.setY(canvasPane.getLayoutY());
        canvasMask.setWidth(width);
        canvasMask.setHeight(height);
        canvasPane.setClip(canvasMask);
        undoList = new ArrayList();
    }


    ////////////////////////////////////////// UI Interaction Events \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @FXML// Validate width/height input, resize canvas and clear the canvas
    void New(ActionEvent event) {
        try {
            if(Integer.parseInt(resolutionWidth.getText()) < minResolution) {
                resolutionWidth.setText(minResolution+"");
            } else if(Integer.parseInt(resolutionWidth.getText()) > maxResolution) {
                resolutionWidth.setText(maxResolution+"");
            }
            if(Integer.parseInt(resolutionHeight.getText()) < minResolution) {
                resolutionHeight.setText(minResolution+"");
            } else if(Integer.parseInt(resolutionHeight.getText()) > maxResolution) {
                resolutionHeight.setText(maxResolution+"");
            }
        } catch(NumberFormatException e) {
            resolutionWidth.setText(width+"");
            resolutionHeight.setText(height+"");
            return;
        }
        width = Integer.parseInt(resolutionWidth.getText());
        height = Integer.parseInt(resolutionHeight.getText());
        initializeCanvas();
    }
    @FXML// Take snapshot of the canvas, prompt user to choose a path
    void SaveAs(ActionEvent event) {//and save in the specified path
        WritableImage img = canvasPane.snapshot(new SnapshotParameters(), null);

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save As");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg"));
        Stage primaryStage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        try {
            path = fileChooser.showSaveDialog(primaryStage).toPath();
        } catch(NullPointerException e) { return; }

        if (path != null) {
            try {
                String extension = "png";
                if(path.getFileName().toString().endsWith(".jpg") || path.getFileName().toString().endsWith(".jpeg"))
                    extension = "jpg";
                else if(!path.getFileName().toString().endsWith(".png"))
                    return;
                ImageIO.write(SwingFXUtils.fromFXImage(img, null), extension, path.toFile());
            } catch(IOException e){
                System.out.println(e);
                return; }
        }
    }
    @FXML// Check if save path is used and save in the specified path
    void Save(ActionEvent event) {//otherwise 'Save As'
        if(path == null || Files.notExists(path)) {
            SaveAs(event);
            return;
        }
        WritableImage img = canvasPane.snapshot(new SnapshotParameters(), null);
        try {
            String extension = "png";
            if(path.getFileName().toString().endsWith(".jpg") || path.getFileName().toString().endsWith(".jpeg"))
                extension = "jpg";
            else if(!path.getFileName().toString().endsWith(".png"))
                return;
            ImageIO.write(SwingFXUtils.fromFXImage(img, null), "png", path.toFile());
        } catch(IOException e){}
    }
    @FXML// Update isPenSelected boolean, and disable toolColorPicker accordingly (no need when erasing)
    void SelectTool(ActionEvent event) {
        isPenSelected = toolComboBox.getSelectionModel().getSelectedIndex() == 0;
        toolColorPicker.setDisable(!isPenSelected);
    }
    @FXML// Update pen color when color is picked
    void SelectToolColor(ActionEvent event) {
        penColor = toolColorPicker.getValue();
    }
    @FXML// remove or add previously removed shapes linked to the last move made
    void Undo(ActionEvent event) {//and update undoList accordingly (pull)
        if(undoList.size() > 0) {
            if(undoList.get(undoList.size() - 1).isAdded) {                                         //Undo Add
                for (int i = 0; i < undoList.get(undoList.size() - 1).shapes.size(); i++) {
                    canvasPane.getChildren().remove(undoList.get(undoList.size() - 1).shapes.get(i));
                }
            } else {                                                                                //Undo Remove
                for (int i = 0; i < undoList.get(undoList.size() - 1).shapes.size(); i++) {
                    canvasPane.getChildren().add((Node)undoList.get(undoList.size() - 1).shapes.get(i));
                }
            }
            undoList.remove(undoList.size() - 1);
        }
    }
    @FXML// Reset to TextFields last known width and height, and New()
    void Clear(ActionEvent event) {
        resolutionWidth.setText(width+"");
        resolutionHeight.setText(height+"");
        New(new ActionEvent());
    }
    @FXML// Check if LMB pressed, update canvas cursor, check what tool is selected, 'Pen' -> check last known mouse position, and render line between last and current
    void UseTool(MouseEvent event) {//'Eraser' -> check intersections in the tool's radius, and remove found move (list of shapes). Update undoList for both
        CanvasHover(event);
        if(event.getButton() == MouseButton.PRIMARY) {
            if(isPenSelected) {                                                     //Draw
                if(previousDrawPositionX != -1 && previousDrawPositionY != -1) {
                    Line newPenEntry = new Line();
                    newPenEntry.setStartX(previousDrawPositionX);
                    newPenEntry.setStartY(previousDrawPositionY);
                    newPenEntry.setEndX(event.getX());
                    newPenEntry.setEndY(event.getY());
                    newPenEntry.setStrokeWidth(toolSizeSlider.getValue()*2);
                    newPenEntry.setStroke(penColor);
                    newPenEntry.setStrokeLineCap(StrokeLineCap.ROUND);
                    canvasPane.getChildren().add(newPenEntry);
                    undoList.get(undoList.size()-1).shapes.add(newPenEntry);
                }
                previousDrawPositionX = (float)event.getX();
                previousDrawPositionY = (float)event.getY();
            } else {                                                               //Erase
                Circle eraseArea = new Circle();
                eraseArea.setCenterX(event.getX());
                eraseArea.setCenterY(event.getY());
                eraseArea.setRadius(toolSizeSlider.getValue());
                for(int i = 0; i < canvasPane.getChildren().size(); i++) {
                    if(canvasPane.getChildren().get(i) == CanvasCursor)
                        continue;
                    if(eraseArea.intersects(canvasPane.getChildren().get(i).getBoundsInLocal())) {
                        for (int j = 0; j < undoList.size(); j++) {
                            for (int k = 0; k < undoList.get(j).shapes.size(); k++) {
                                if(canvasPane.getChildren().get(i) == undoList.get(j).shapes.get(k)) {
                                    UndoElement removedElement = new UndoElement(undoList.get(j).shapes, false);
                                    undoList.add(removedElement);
                                    for (int t = 0; t < undoList.get(j).shapes.size(); t++) {
                                        canvasPane.getChildren().remove(undoList.get(j).shapes.get(t));
                                    }
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    ////////////////////////////////////////// IO Input Events \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @FXML //Set tool as 'Pen' when the key 'P' is pressed, and 'Eraser' when 'E' is pressed
    void QuickSelectTool(KeyEvent event) {//and disable the toolColorPicker accordingly (no need when erasing)
        if(event.getCharacter().equals("p"))
            toolComboBox.setValue("Pen");
        else if(event.getCharacter().equals("e"))
            toolComboBox.setValue("Eraser");
        isPenSelected = toolComboBox.getSelectionModel().getSelectedIndex() == 0;
        toolColorPicker.setDisable(!isPenSelected);
    }
    @FXML //Increment/Decrement toolSizeSlider value with respect to the sign of scroll wheel delta
    void QuickResizeTool(ScrollEvent event) {//and update the new canvas cursor (hollow circle with radius = toolSizeSlider value)
        toolSizeSlider.setValue(toolSizeSlider.getValue() + (event.getDeltaY() > 0? scrollSizeStep : -scrollSizeStep));
        canvasPane.getChildren().remove(CanvasCursor);
        if(isInsideCanvas(event.getX(), event.getY()))
            return;
        CanvasCursor = new Circle(event.getX(), event.getY(), toolSizeSlider.getValue(), Color.TRANSPARENT);
        CanvasCursor.setStroke(Color.BLACK);
        CanvasCursor.setStrokeWidth(2);
        canvasPane.getChildren().add(CanvasCursor);
    }
    @FXML //Set last known position of the mouse, when LMB is initially clicked and add an initial circle shape for precision
    void InitialMouseCanvasClick(MouseEvent event) {//and prepare undoList to next stream of shapes -> UndoElements(shapeArrayList, isAdded)
        if(event.getButton() == MouseButton.PRIMARY) {
            previousDrawPositionX = (float) event.getX();
            previousDrawPositionY = (float) event.getY();
            if (isPenSelected) {
                if (undoList.size() == undoListMaxSize) {
                    undoList.remove(0);
                }
                undoList.add(new UndoElement(new ArrayList(), true));
                Circle initialDraw = new Circle(event.getX(), event.getY(), toolSizeSlider.getValue(), penColor);
                canvasPane.getChildren().add(initialDraw);
                undoList.get(undoList.size() - 1).shapes.add(initialDraw);
            }
        }
    }
    @FXML //Reset last known position of the mouse, when LMB is released
    void FinalMouseCanvasClick(MouseEvent event) {
        if(event.getButton() == MouseButton.PRIMARY) {
            previousDrawPositionX = -1;
            previousDrawPositionY = -1;
        }
    }
    @FXML //Update last known position of the mouse, when it is inside the canvas (hovering)
    void CanvasHover(MouseEvent event) { //and render new cursor inside the canvas
        canvasPane.getChildren().remove(CanvasCursor);
        if(isInsideCanvas(event.getX(), event.getY()))
            return;

        CanvasCursor = new Circle(event.getX(), event.getY(), toolSizeSlider.getValue(), Color.TRANSPARENT);
        CanvasCursor.setStroke(Color.BLACK);
        CanvasCursor.setStrokeWidth(2);
        canvasPane.getChildren().add(CanvasCursor);
    }
    @FXML //Reset last known position of the mouse, when it exists the canvas
    void CanvasHoverExit(MouseEvent event) { //and stop rendering the canvas cursor
        canvasPane.getChildren().remove(CanvasCursor);
        previousDrawPositionX = -1;
        previousDrawPositionY = -1;
    }
    @FXML //Update last known position of the mouse, when it enters the canvas
    void CanvasHoverEnter(MouseEvent event) {
        previousDrawPositionX = (float)event.getX();
        previousDrawPositionY = (float)event.getY();
    }

    ////////////////////////////////////////// Helper Method \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    //Check if (x, y) is inside the canvas rect
    private boolean isInsideCanvas(double x, double y) {
        return x > width || y > height;
    }
}

//Helper Class UndoElement Data Structure
class UndoElement {

    public ArrayList<Object> shapes;
    public boolean isAdded;

    public UndoElement(ArrayList<Object> shapes, boolean isAdded) {
        this.shapes = shapes;
        this.isAdded = isAdded;
    }
}
